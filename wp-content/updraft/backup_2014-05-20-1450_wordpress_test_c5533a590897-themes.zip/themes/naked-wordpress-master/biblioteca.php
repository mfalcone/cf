<?php
/*
Template Name: biblioteca
*/
get_header();
?>

<p>Soy template</p>
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/biblioteca.js"></script>
<?php get_footer();?>
