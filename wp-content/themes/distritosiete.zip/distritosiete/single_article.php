<div id="main" class="content">
<article class="post">

	<h1 class="title"><?php the_title(); // Display the title of the post ?></h1>
	
	<div class="the-content">
		<?php the_content(); 
		// This call the main content of the post, the stuff in the main text box while composing.
		// This will wrap everything in p tags
		?>
		
	</div><!-- the-content -->
	
	
</article>
</div>