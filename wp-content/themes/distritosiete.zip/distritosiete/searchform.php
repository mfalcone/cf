<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
     <fieldset>
         <input type="search" placeholder="buscar..." id="s" name="s" placeholder="Enter keywords" required />
         <button type="submit" id="searchsubmit" alt="buscar">Buscar</button>
         <input type="image" id="searchsubmiticon" alt="Search" src="<?php bloginfo( 'template_url' ); ?>/img/searchicon.png" />
     </fieldset>
</form>
